from exportkml import kmlclass
print ('Creating the file testfile.kml as an example on how to use kmlclass')
# width: defines the line width, use e.g. 0.1 - 1.0
kml = kmlclass()
kml.begin('test1.kml', 'Example', 'Example on the use of kmlclass', 0.7)
# color: red,green,blue,cyan,yellow,grey,red_poly,yellow_poly,green_poly
# altitude: use 'absolute' or 'relativeToGround'
kml.trksegbegin ('', '', 'red', 'absolute') 
kml.pt(55.47, 10.33, 0.0)
kml.pt(55.47, 10.34, 0.0)
kml.pt(55.48, 10.34, 0.0)
kml.pt(55.47, 10.33, 0.0)
kml.trksegend()
kml.end()