#!/usr/bin/env python3
#/****************************************************************************
# nmea read function
# Copyright (c) 2018-2020, Kjeld Jensen <kj@kjen.dk>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#    * Neither the name of the copyright holder nor the names of its
#      contributors may be used to endorse or promote products derived from
#      this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#****************************************************************************/
'''
2018-03-13 Kjeld First version, that reads in CSV data
2020-02-03 Kjeld Python 3 compatible
2020-09-17 Kjeld Changed first line to python3
'''
import matplotlib.pyplot as plt
from exportkml import kmlclass
class nmea_class:
  def __init__(self):
    self.data = []
    self.timedata=[]
    self.timedataCorrected=[]
    self.sataliteNumber=[]
    self.Alttitude=[]
    self.timebias=0
    self.gpgga=[]
    self.gpgsv=[]
    self.gpgsa=[]
    self.gprmc=[]
    self.gpvtg=[]
    self.gpgll=[]


  def import_file(self, file_name):
    if file_name=='nmea_ublox_neo_24h_static.txt':
      file_ok = True
      try:
        # read all lines from the file and strip \n
        lines = [line.rstrip() for line in open(file_name)]   
      except:
        file_ok = False
      if file_ok == True:
        pt_num = 0
        for i in range(len(lines)): # for all lines
          if len(lines[i]) > 0 and lines[i][0] != '#': # if not a comment or empty line
            csv = lines[i].split (',') # split into comma separated list
            if len(csv)>1:
              if(csv[0]=='$GPGGA'):
                self.gpgga.append(csv)
              if(csv[0]=='$GPGSV'):
                self.gpgsv.append(csv)
              if(csv[0]=='$GPGSA'):
                self.gpgsa.append(csv)
              if(csv[0]=='$GPRMC'):
                self.gprmc.append(csv)
              if(csv[0]=='$GPVTG'):
                self.gpvtg.append(csv)
              if(csv[0]=='$GPGLL'):
                self.gpgll.append(csv)
        print('Done')
    else:
      file_ok = True
      try:
        # read all lines from the file and strip \n
        lines = [line.rstrip() for line in open(file_name)] 
      except:
        file_ok = False
      if file_ok == True:
        pt_num = 0
        for i in range(len(lines)): # for all lines
          if len(lines[i]) > 0 and lines[i][0] != '#': # if not a comment or empty line
            csv = lines[i].split (',') # split into comma separated list
            if len(csv)>1:
              self.data.append(csv)
              self.timedata.append(float(csv[1]))
              self.Alttitude.append(float(csv[9]))
              self.sataliteNumber.append(int(csv[7]))
          
          

  def print_data(self):
    for i in range(len(self.data)):
      print (self.data[i])
  def correct_timedata(self):
    self.timebias=self.timedata[0]
    self.timedataCorrected=[x-self.timebias for x in self.timedata]
  def plot_sat_data(self):
    plt.plot(self.timedataCorrected,self.sataliteNumber,label='Number of satalites')
    plt.legend()
    plt.ylabel('Number of satalites tracked')
    plt.xlabel('Time [Sec]')
    plt.show()
  def plot_Altitude_above_mean_sea_level(self):
    plt.plot(self.timedataCorrected,self.Alttitude,label='Mean altitude above the water')
    plt.legend()
    plt.ylabel('Mean alttitude [M]')
    plt.xlabel('Time [Sec]')
    plt.show()

  def plot_signal_to_noise_ratio(self):
    snr_time=[]
    snr_time_corrected=[]
    if len(self.gpgsv)>0:
      print('file is loaded')
    else:
      print('Correct file not loaded yet')
  
  def make_waypoint_map(self,file_name,static):
    if static==True:
      print('static')
      kml=kmlclass()
      kml.begin(file_name+'.kml', 'Example', 'hopeitworks', 0.7)
      kml.trksegbegin ('', '', 'red', 'absolute') 
      for i in range(len(self.gpgga)):
        if(len(self.gpgga[i][2])>0 and len(self.gpgga[i][4])>0 and len(self.gpgga[i][4])>0):
         kml.pt(float(self.gpgga[i][2][0:2])+float(self.gpgga[i][2][2:])/60,float(self.gpgga[i][4][0:3])+float(self.gpgga[i][4][2:])/60,0)
      kml.trksegend()
      kml.end()
    else:
      kml=kmlclass()
      kml.begin(file_name+'.kml', 'Example', 'hopeitworks', 0.7)
      kml.trksegbegin ('', '', 'red', 'absolute') 
      for i in range(len(self.data)):
        kml.pt(float(self.data[i][2][0:2])+float(self.data[i][2][2:])/60,float(self.data[i][4][0:3])+float(self.data[i][4][2:])/60,0)
      kml.trksegend()
      kml.end()

    
  
    
   

if __name__ == "__main__":
  print ('Importing file')
  nmea = nmea_class()
  nmea.import_file ('nmea_trimble_gnss_eduquad_flight.txt')
 # nmea.plot_signal_to_noise_ratio()
 # nmea.correct_timedata()
 # nmea.plot_sat_data()
 # nmea.plot_Altitude_above_mean_sea_level()
  nmea.make_waypoint_map('test4',False)
  nmea.import_file('nmea_ublox_neo_24h_static.txt')
  #nmea.plot_Altitude_above_mean_sea_level()
  #nmea.plot_signal_to_noise_ratio()
  nmea.make_waypoint_map('test3',True)
  #nmea.print_data()