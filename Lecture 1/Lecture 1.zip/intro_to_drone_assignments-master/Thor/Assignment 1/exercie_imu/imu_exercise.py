#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# IMU exercise
# Copyright (c) 2015-2020 Kjeld Jensen kjen@mmmi.sdu.dk kj@kjen.dk

##### Insert initialize code below ###################

## Uncomment the file to read ##
fileName = 'imu_razor_data_static.txt'
#fileName = 'imu_razor_data_pitch_55deg.txt'
#fileName = 'imu_razor_data_roll_65deg.txt'
#fileName = 'imu_razor_data_yaw_90deg.txt'

## IMU type
#imuType = 'vectornav_vn100'
imuType = 'sparkfun_razor'

## Variables for plotting ##
<<<<<<< HEAD
showPlot = False
showPitchPlot=False
showRoolPlot=False
Low_pass_plots=False
Accelerometer_noise=False
Calc_relatice_angle=False
ObservingBias=True
=======
Accelerometer_noise=True
showPlot = True
showPitchPlot=True
showRoolPlot=True
>>>>>>> 36d7b6b63d49f06d9807f322660b4368ce6760e1
plotData = []
angledata_x=[]
angledata_y=[]
angledata_z=[]
angledata_x_mean_bias=[]
angledata_y_mean_bias=[]
angledata_z_mean_bias=[]

angledata_x_unfiltered=[]
angledata_y_unfiltered=[]
angledata_z_unfiltered=[]
pitchdata=[]
rooldata=[]
staticdata=[]

## Initialize your variables here ##
myValue = 0.0






######################################################

# import libraries
from math import pi, sqrt, atan2
import matplotlib.pyplot as plt
import numpy as np 
from scipy.signal import butter, filtfilt
from scipy.fft import fft, fftfreq, fftshift


# open the imu data file
f = open (fileName, "r")

# initialize variables
count = 0
Freq=100
Nyq=0.5*Freq
T=1764/Freq
order=2
n=1764
cutoff=0.4
print(T)
angle_x=0
angle_y=0
angle_z=0
angle_x_mean_bias=0
angle_y_mean_bias=0
angle_z_mean_bias=0
angle_x_un_filtered=0
angle_y_un_filtered=0
angle_z_un_filtered=0
rool=0



# looping through file

for line in f:
	count += 1

	# split the line into CSV formatted data
	line = line.replace ('*',',') # make the checkum another csv value
	csv = line.split(',')

	# keep track of the timestamps 
	ts_recv = float(csv[0])
	if count == 1: 
		ts_now = ts_recv # only the first time
	ts_prev = ts_now
	ts_now = ts_recv

	if imuType == 'sparkfun_razor':
		# import data from a SparkFun Razor IMU (SDU firmware)
		acc_x = int(csv[2]) / 1000.0 * 4 * 9.82;
		acc_y = int(csv[3]) / 1000.0 * 4 * 9.82;
		acc_z = int(csv[4]) / 1000.0 * 4 * 9.82;
		gyro_x = int(csv[5]) * 1/14.375 * pi/180.0;
		gyro_y = int(csv[6]) * 1/14.375 * pi/180.0;
		gyro_z = int(csv[7]) * 1/14.375 * pi/180.0;

	elif imuType == 'vectornav_vn100':
		# import data from a VectorNav VN-100 configured to output $VNQMR
		acc_x = float(csv[9])
		acc_y = float(csv[10])
		acc_z = float(csv[11])
		gyro_x = float(csv[12])
		gyro_y = float(csv[13])
		gyro_z = float(csv[14])
	 		
	##### Insert loop code below #########################

	# Variables available
	# ----------------------------------------------------
	# count		Current number of updates		
	# ts_prev	Time stamp at the previous update
	# ts_now	Time stamp at this update
	# acc_x		Acceleration measured along the x axis
	# acc_y		Acceleration measured along the y axis
	# acc_z		Acceleration measured along the z axis
	# gyro_x	Angular velocity measured about the x axis
	# gyro_y	Angular velocity measured about the y axis
	# gyro_z	Angular velocity measured about the z axis

	## Insert your code here ##
	
	
	pitch=atan2(acc_y,(sqrt(acc_x**2+acc_z**2)))	
	roll=atan2(-acc_x,acc_z)
	myValue = pitch # relevant for the first exercise, then change this.
	rooldata.append(roll*180/pi)
	pitchdata.append(pitch*180.0/pi)
	dt=ts_now-ts_prev
	# in order to show a plot use this function to append your value to a list:
	plotData.append (myValue*180.0/pi)
	bias_gyro_z=(0.04660-0)/(5923-0) # slope of a straight line. 
	#angle_x+=(gyro_x*dt)-7.867634644605775e-06  saving this line becuse it hase the right value for the z bias. 
	angle_x+=(gyro_x)*dt-0.0007417244191025366
	angle_y+=(gyro_y)*dt-0.0004109444493122052
	angle_z+=(gyro_z)*dt-7.866362791301079e-06
	
	angle_x_mean_bias+=(gyro_x)*dt-(0 if not angledata_x_mean_bias else np.mean(angledata_x_mean_bias))
	angle_y_mean_bias+=(gyro_y)*dt-(0 if not angledata_y_mean_bias else np.mean(angledata_y_mean_bias))
	angle_z_mean_bias+=(gyro_z)*dt-(0 if not angledata_z_mean_bias else np.mean(angledata_z_mean_bias))
	
	#append the data
	angledata_x.append(angle_x)
	angledata_y.append(angle_y)
	angledata_z.append(angle_z)
	
	angledata_x_mean_bias.append(angle_x_mean_bias*180/pi)
	angledata_y_mean_bias.append(angle_y_mean_bias*180/pi)
	angledata_z_mean_bias.append(angle_z_mean_bias*180/pi)
	
	angle_x_un_filtered+=gyro_x*dt
	angle_y_un_filtered+=gyro_y*dt
	angle_z_un_filtered+=gyro_z*dt
	
	angledata_x_unfiltered.append(angle_x_un_filtered*180/pi)
	angledata_y_unfiltered.append(angle_y_un_filtered*180/pi)
	angledata_z_unfiltered.append(angle_z_un_filtered*180/pi)

	######################################################

# closing the file	
f.close()

#finding the bias assuming it is linear 
bias_gyro_x=(angledata_x[-1]-angledata_x[0])/(len(angledata_x)-0)
bias_gyro_y=(angledata_y[-1]-angledata_y[0])/(len(angledata_y)-0)
bias_gyro_z=(angledata_z[-1]-angledata_z[0])/(len(angledata_z)-0)

print("The bias for z is : ",bias_gyro_z, "The bias for y is : ",bias_gyro_y, "The bias for x is : ",bias_gyro_x)

#finding the bias by meanings the data
bias_gyro_x_mean=np.mean(angledata_x)
bias_gyro_y_mean=np.mean(angledata_y)
bias_gyro_z_mean=np.mean(angledata_z)
print("The bias for z is : ",bias_gyro_z_mean, "The bias for y is : ",bias_gyro_y_mean, "The bias for x is : ",bias_gyro_x_mean)






def butter_wort_filter(data,cutoff, fs, order, nyq):
	normal_cutoff=cutoff/nyq
	b,a=butter(order,normal_cutoff,btype='low',analog=False)
	y=filtfilt(b,a,data)
	return y


y=butter_wort_filter(rooldata,cutoff,Freq,order,Nyq)
x=butter_wort_filter(pitchdata,cutoff,Freq,order,Nyq)


# show the plot
if ObservingBias ==True:

	plt.suptitle('3.3.3 Observing bias')
	plt.subplot(1,3,1)
	plt.title('x axis')
	plt.ylabel('Angel [Deg]')
	plt.xlabel('Sampels')
	plt.plot(angledata_x_unfiltered,label='Bias not removed')
	plt.plot(angledata_x,label='Bias removed')
	plt.legend()
	plt.subplot(1,3,2)
	plt.title('y axis')
	plt.plot(angledata_y_unfiltered,label='Bias not removed')
	plt.plot(angledata_y,label='Bias removed')
	plt.xlabel('Sampels')
	plt.ylabel('Angle [Deg]')
	plt.legend()
	plt.subplot(1,3,3)
	plt.title('z axis')
	plt.xlabel('Sampels')
	plt.ylabel('Angle [Deg]')
	plt.plot(angledata_z_unfiltered,label='Bias not removed')
	plt.plot(angledata_z,label='Bias removed')
	plt.legend()
	plt.show()
if Calc_relatice_angle ==True:
	plt.title('3.3.1 Calculating relative angle')
	plt.plot(angledata_z_unfiltered,label='Bias not removed')
	plt.plot(angledata_z,label='Bias removed')
	plt.xlabel('Sampels')
	plt.ylabel('Angle [Deg]')
	plt.show()
if Low_pass_plots==True:
	plt.subplot(1,2,1)
	plt.suptitle('3.2.4 Low pass filtering')
	plt.title('Roll')
	plt.xlabel('Sampels')
	plt.ylabel('Angle [Deg]')
	plt.plot(rooldata,label=('Roll unfiltered'))
	plt.plot(y,label='Pitch filtered')
	plt.legend()
	plt.subplot(1,2,2)
	plt.title('Pitch')
	plt.xlabel('Sampels')
	plt.ylabel('Angle [Deg]')
	plt.plot(pitchdata,label='Pitch unfiltered')
	plt.plot(x,label='Pitch filtered')
	plt.legend()
	plt.show()
if Accelerometer_noise == True:
	plt.subplot(1,2,1)
	plt.plot(rooldata, label='Roll')
	plt.grid()
	plt.legend()
	plt.title('3.2.3 Roll')
	plt.ylabel('Angle [deg]')
	plt.xlabel('Samples')
	
	plt.subplot(1,2,2)
	plt.plot(pitchdata, label='Pitch')
	plt.grid()
	plt.legend()
	plt.title('3.2.3 Pitch')
	plt.ylabel('Angle [deg]')
	plt.xlabel('Samples')
	plt.show()


if showPitchPlot==True:
	plt.plot(pitchdata, label='Pitch')
	plt.grid()
	plt.legend()
	plt.title('3.2.1 Pitch')
	plt.ylabel('Angle [deg]')
	plt.xlabel('Samples')
	plt.show()

if showPlot == True:

	plt.figure(0)
	plt.subplot(1,3,1)
	plt.plot(angledata_x_unfiltered)
	plt.subplot(1,3,2)
	plt.plot(angledata_y_unfiltered)
	plt.subplot(1,3,3)
	plt.plot(angledata_z_unfiltered)
<<<<<<< HEAD
	#plt.show()
=======
	plt.show()

	
>>>>>>> 36d7b6b63d49f06d9807f322660b4368ce6760e1
	plt.figure(1)
	plt.subplot(2,3,1)
	plt.plot(angledata_x)
	plt.subplot(2,3,2)
	plt.plot(angledata_y)
	plt.subplot(2,3,3)
	plt.plot(angledata_z)
	plt.subplot(2,3,4)
	plt.plot(angledata_x_mean_bias)
	plt.subplot(2,3,5)
	plt.plot(angledata_y_mean_bias)
	plt.subplot(2,3,6)
	plt.plot(angledata_z_mean_bias)
	plt.show()
	print(len(plotData))
	plt.figure(2)
	plt.plot(plotData,'b-',label='unfiltered')
	#plt.plot(plotData,'g-',label='filtered')
	plt.savefig('imu_exercise_plot.png')
	plt.show()


