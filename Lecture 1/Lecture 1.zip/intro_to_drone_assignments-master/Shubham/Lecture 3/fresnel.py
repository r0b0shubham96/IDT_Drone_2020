import matplotlib.pyplot as plt
import matplotlib.patches as patch
import math

def calc_radius(Distance_km,Freq_Ghz):
    return 17.31*math.sqrt(Distance_km/(4*Freq_Ghz))
print(calc_radius(0.1,2.4))

fig=plt.figure(0)
ex=fig.add_subplot(111,aspect='equal')
elips=patch.Ellipse((5,5),10,calc_radius(0.1,2.4)*2,0)
elips.set_visible(True)
elips.set_fill(False)
elips.set_linestyle('-')
ex.add_artist(elips)

ex.set_xlim(0,10)
ex.set_ylim(0,10)
plt.title('Fresnal sone For 2.4 Ghz ')
plt.xlabel('Distance M')
plt.ylabel('Height M')
plt.show()

fig=plt.figure(1)
ex=fig.add_subplot(111,aspect='equal')
elips=patch.Ellipse((5,5),10,calc_radius(0.1,5.2),0)
elips.set_visible(True)
elips.set_fill(False)
elips.set_linestyle('-')
ex.add_artist(elips)

ex.set_xlim(0,10)
ex.set_ylim(0,10)
plt.title('Fresnal sone For 5.2 Ghz ')
plt.xlabel('Distance M')
plt.ylabel('Height M')
plt.show()

fig=plt.figure(3)
ex=fig.add_subplot(111,aspect='equal')
elips=patch.Ellipse((5,5),10,calc_radius(0.1,0.433),0)
elips.set_visible(True)
elips.set_fill(False)
elips.set_linestyle('-')
ex.add_artist(elips)

ex.set_xlim(0,10)
ex.set_ylim(0,10)
plt.xlabel('Distance M')
plt.ylabel('Height M')
plt.title('Fresnal sone For 433 mhz ')
plt.show()
